//
//  ELText.cpp
//  LogAnalyzer
//
//  Created by Dileepa Jayathilaka on 1/11/14.
//  Copyright (c) 2014 99x Eurocenter. All rights reserved.
//

#include "ELText.h"

ELText::ELText ()
: ELString() {
    AddChar(' ');
    AddChar('\t');
}

ELText::~ELText() {
    
}
