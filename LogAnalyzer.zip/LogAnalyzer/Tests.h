// #ifndef _TESTS_H
// #define _TESTS_H

// #include "CommonIncludes.h"

// class Tests
// {
// public:
// 	void RunTest1();
// 	void RunTest2();
// 	void RunTest3();
// 	void RunTest4();
//     void RunTest5();
//     void RunTest6();
//     void TDPTest();
//     void LogTest();
// };



// #endif