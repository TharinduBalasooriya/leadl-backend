//
//  ELNumber.h
//  LogAnalyzer
//
//  Created by Dileepa Jayathilaka on 12/24/13.
//  Copyright (c) 2013 99x Eurocenter. All rights reserved.
//

#ifndef __LogAnalyzer__ELNumber__
#define __LogAnalyzer__ELNumber__

#include <iostream>
#include "ELFillerString.h"

class ELNumber : public ELFillerString {
public:
    ELNumber();
    virtual ~ELNumber();
};

#endif /* defined(__LogAnalyzer__ELNumber__) */
