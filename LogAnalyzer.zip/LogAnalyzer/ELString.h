//
//  ELString.h
//  LogAnalyzer
//
//  Created by Dileepa Jayathilaka on 12/24/13.
//  Copyright (c) 2013 99x Eurocenter. All rights reserved.
//

#ifndef __LogAnalyzer__ELString__
#define __LogAnalyzer__ELString__

#include <iostream>
#include "ELFillerString.h"

class ELString : public ELFillerString {
public:
    ELString();
    virtual ~ELString();
};

#endif /* defined(__LogAnalyzer__ELString__) */
