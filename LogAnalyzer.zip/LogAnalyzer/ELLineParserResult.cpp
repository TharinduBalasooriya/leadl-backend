//
//  ELLineParserResult.cpp
//  LogAnalyzer
//
//  Created by Dileepa Jayathilaka on 12/24/13.
//  Copyright (c) 2013 99x Eurocenter. All rights reserved.
//

#include "ELLineParserResult.h"

ELLineParserResult::ELLineParserResult() {
    entityName = EMPTY_STRING;
    entityType = AssignmentType_None;
    expression = EMPTY_STRING;
}

ELLineParserResult::~ELLineParserResult() {
    
}


