// //
// // Created by AfazD on 14-Nov-19.
// //

// #ifndef FLEXIBLECOMPUTERLANGUAGE_QUERYEXECUTER_H
// #define FLEXIBLECOMPUTERLANGUAGE_QUERYEXECUTER_H


// class QueryExecuter{

// public:
//     static MSTRING run(Node *root, MSTRING querycode);
// };


// #endif //FLEXIBLECOMPUTERLANGUAGE_QUERYEXECUTER_H
