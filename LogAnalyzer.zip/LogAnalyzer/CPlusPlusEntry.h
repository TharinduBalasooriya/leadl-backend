// //
// //  CPlusPlusEntry.h
// //  LogAnalyzer
// //
// //  Created by Dileepa Jayathilake on 7/4/13.
// //  Copyright (c) 2013 99x Eurocenter. All rights reserved.
// //

// #ifndef __LogAnalyzer__CPlusPlusEntry__
// #define __LogAnalyzer__CPlusPlusEntry__

// #include <iostream>

// class CPlusPlusEntry {
// public:
//     void RunMenu();
//     void RunDefault();
// private:
    
// };

// #endif /* defined(__LogAnalyzer__CPlusPlusEntry__) */
