#include <iostream>
#include <fstream>
#include <list>
#include <map>
#include <iterator>
#include <vector>
#include <set>
#include <stack>
#include <algorithm>
#include <cstring>
#include <assert.h>

#include "Defs.h"
#include "TypeDefs.h"

