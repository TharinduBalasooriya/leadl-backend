// //
// // Created by Michelle on 12/31/2019.
// //

// #ifndef FLEXIBLECOMPUTERLANGUAGE_QUERYTREESCRIPT_H
// #define FLEXIBLECOMPUTERLANGUAGE_QUERYTREESCRIPT_H

// class QueryTreeScript {
// public:
//     static void QueryNodeTree(Node *root);
// };

// #endif //FLEXIBLECOMPUTERLANGUAGE_QUERYTREESCRIPT_H
